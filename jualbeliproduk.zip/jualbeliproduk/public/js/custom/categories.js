$(document).ready(function() {
	filter_categories();
});
function filter_categories() {
	$(".filter-category").on('change', function() {
		
	});
}