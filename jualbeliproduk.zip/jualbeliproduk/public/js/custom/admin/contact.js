$(document).ready(function() {
	contact_datatable();
});
function contact_datatable() {
	$("#contact").DataTable();
}