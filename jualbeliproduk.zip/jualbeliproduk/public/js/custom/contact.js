$(document).ready(function() {
	toastr.success('Success Inserted.', 'Contact');
});