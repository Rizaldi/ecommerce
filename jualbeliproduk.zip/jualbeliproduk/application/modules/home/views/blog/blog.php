
<div class="blog-page-area">
		    <div class="container">
		        <div class="row">
                    <div class="col-md-12">  
                        <div class="breadcrumbs">
                            <ul>
                                <li><a href="index.html">Home</a></li>
                                <li class="active">Blog</li>
                            </ul>
                        </div>  
                    </div>
                    <div class="col-md-6 col-6">
                       <div class="single-blog pb-60">
                            <div class="blog-img">
                                <a href="blog-details.html"><img src="<?php echo base_url(); ?>public/img/blog/blog1.png" alt="blog"></a>
                            </div>
                            <div class="blog-con">
                                <h3><a href="blog-details.html">Velit esse molestie consequat</a></h3>
                                <div class="date-post fix">
                                    <div class="date">
                                        <h4>18 <span>aug</span></h4>   
                                    </div>
                                    <div class="post-admin">
                                        <p>Posted by: Admin</p>
                                    </div>
                                </div>
                                <p>Lorem ipsum dolor sit amet, consectetuer adipisc-ing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </p>
                                <a href="blog-details.html" class="read-more">Read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-6">    
                       <div class="single-blog pb-60">
                            <div class="blog-img">
                                <a href="blog-details.html"><img src="<?php echo base_url(); ?>public/img/blog/blog2.png" alt="blog"></a>
                            </div>
                            <div class="blog-con">
                                <h3><a href="blog-details.html">Velit esse molestie consequat</a></h3>
                                <div class="date-post fix">
                                    <div class="date">
                                        <h4>12 <span>sep</span></h4>   
                                    </div>
                                    <div class="post-admin">
                                        <p>Posted by: Admin</p>
                                    </div>
                                </div>
                                <p>Lorem ipsum dolor sit amet, consectetuer adipisc-ing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </p>
                                <a href="#" class="read-more">Read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-6">
                       <div class="single-blog pb-60">
                            <div class="blog-img">
                                <a href="shop.html"><img src="<?php echo base_url(); ?>public/img/blog/blog3.png" alt="blog"></a>
                            </div>
                            <div class="blog-con">
                                <h3><a href="blog-details.html">Velit esse molestie consequat</a></h3>
                                <div class="date-post fix">
                                    <div class="date">
                                        <h4>20 <span>oct</span></h4>   
                                    </div>
                                    <div class="post-admin">
                                        <p>Posted by: Admin</p>
                                    </div>
                                </div>
                                <p>Lorem ipsum dolor sit amet, consectetuer adipisc-ing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </p>
                                <a href="blog-details.html" class="read-more">Read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-6">    
                       <div class="single-blog pb-60">
                            <div class="blog-img">
                                <a href="blog-details.html"><img src="<?php echo base_url(); ?>public/img/blog/blog4.png" alt="blog"></a>
                            </div>
                            <div class="blog-con">
                                <h3><a href="blog-details.html">Velit esse molestie consequat</a></h3>
                                <div class="date-post fix">
                                    <div class="date">
                                        <h4>25 <span>nov</span></h4>   
                                    </div>
                                    <div class="post-admin">
                                        <p>Posted by: Admin</p>
                                    </div>
                                </div>
                                <p>Lorem ipsum dolor sit amet, consectetuer adipisc-ing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </p>
                                <a href="blog-details.html" class="read-more">Read more</a>
                            </div>
                        </div>
                    </div>
                </div>
		    </div>
		</div>
		<!-- Login Area End -->