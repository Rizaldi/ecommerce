<link rel="stylesheet" href="<?php echo base_url('') ?>public/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url('') ?>public/css/animate.css">
<link rel="stylesheet" href="<?php echo base_url('') ?>public/css/meanmenu.css">
<link rel="stylesheet" href="<?php echo base_url('') ?>public/css/owl.carousel.min.css">
<link rel="stylesheet" href="<?php echo base_url('') ?>public/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url('') ?>public/css/slick.css">
<link rel="stylesheet" href="<?php echo base_url('') ?>public/css/style.css">
<link rel="stylesheet" href="<?php echo base_url('') ?>public/css/responsive.css">
<style>
.payment__list {
	background: #fff;
	border-bottom: 1px solid #ededed;
	cursor: pointer;
	height: 		;
	padding: 0 16px 0 0;
	box-sizing: content-box;
	overflow: hidden;
	margin-left: 16px;
}
.payment__box__shadow {
	padding-top: 16px;
	box-shadow: rgba(0,0,0,.12) 0 2px 6px 0.5px;
}
</style>
<br>
<div>
	<h6>Transfer Bank (Verifikasi Manual)</h6>
	<hr>
	<div class="card" style="width: 100%;">
		<ul class="list-group list-group-flush">
			<li class="list-group-item" style="padding: 25px;"><a href="#"><img src="<?php echo base_url('public/img/icon/bca.png') ?>" style="height: 20px;"> <span style="color:black;margin-left: 5%;font-size: 15px;"> <b> Bank BCA </b> </span><i class="fa fa-chevron-right float-right"></i></a></li>
			<li class="list-group-item" style="padding: 25px;"><a href="#"><img src="<?php echo base_url('public/img/icon/mandiri.png') ?>" style="height: 20px;"> <span style="color:black;margin-left: 7%;font-size: 15px;"> <b> Bank MANDIRI </b> </span> <i class="fa fa-chevron-right float-right"></i></a></li>
			<li class="list-group-item" style="padding: 25px;"><a href="#"><img src="<?php echo base_url('public/img/icon/bri.png') ?>" style="height: 15px;"> <span style="color:black;margin-left: 5%;font-size: 15px;"> <b> Bank BRI </b> </span> <i class="fa fa-chevron-right float-right"></i></a></li>
			<li class="list-group-item" style="padding: 25px;"><a href="#"><img src="<?php echo base_url('public/img/icon/bni.png') ?>" style="height: 20px;"> <span style="color:black;margin-left: 5%;font-size: 15px;"> <b> Bank BNI </b> </span> <i class="fa fa-chevron-right float-right"></i></a></li>
		</ul>
	</div>
</div>
