<?php

$lang["menu_product"] = "Produk";

$lang["menu_services"] = "Servis";

$lang["menu_blog"] = "Blog";

$lang["menu_contact"] = "Kontak Kami";

$lang["menu_cart"] = "Troli Saya";

$lang["menu_categories"] = "Semua Kategori";


$lang["new_product"] = "Produk Terbaru";

$lang["on_sale"] = "Sedang Obral";

$lang["shipping"] = "Pengiriman";
$lang["large_selection"] = "Banyak Pilihan";

$lang["money_back_guarantee"] = "Garansi Uang Kembali";
$lang["100_money_back"] = "100% Uang Kembali";

$lang["24_hours_support"] = "24 Jam Support";
$lang["Monday_to_friday"] = "24 jam / 7 hari Senin Ke Jumat";
$lang["best_seller"] = "Produk Paling Laris";

