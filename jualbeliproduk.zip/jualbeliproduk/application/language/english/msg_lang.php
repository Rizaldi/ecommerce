<?php

$lang["menu_product"] = "Product";

$lang["menu_services"] = "Service";

$lang["menu_blog"] = "Blog";

$lang["menu_contact"] = "Contact us";

$lang["menu_cart"] = "My Cart";

$lang["menu_categories"] = "All Categories";

$lang["new_product"] = "New Products";

$lang["on_sale"] = "On Sale";

$lang["best_seller"] = "Best Seller Products";

$lang["new_product"] = "new products";

$lang["on_sale"] = "on sale";

$lang["best_seller"] = "Best Seller Products";

$lang["shipping"] = "shipping";
$lang["large_selection"] = "Large selection";

$lang["money_back_guarantee"] = "MONEY BACK GUARANTE";
$lang["100_money_back"] = "100% Money-back guarantee";

$lang["24_hours_support"] = "24 HOURS SUPPORT";
$lang["Monday_to_friday"] = "24 / 7 from Monday to Friday";

