<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">  
                <div class="breadcrumbs">
                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li class="active">Product Details</li>
                    </ul>
                </div>  
            </div>
        </div>
    </div>
</div>