<?php

$config['pusher_app_id']     = '464759';
$config['pusher_app_key']    = '18c2dd92dad0b3a684c1';
$config['pusher_app_secret'] = '6fc1cc63d42cdcaafc80';
$config['pusher_debug']      = FALSE;