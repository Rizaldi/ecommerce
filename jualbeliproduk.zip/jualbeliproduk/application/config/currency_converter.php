<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

$config['currency_converter_db_table'] = 'currency_converter';