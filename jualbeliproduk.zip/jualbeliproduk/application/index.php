<!DOCTYPE html>
<html>
<head>
	<title>403 Forbidden</title>
</head>
<script type="text/javascript">window.location = "https://www.baboo.id/";</script>
<body>

<p>Directory access is forbidden.</p>

</body>
</html>
